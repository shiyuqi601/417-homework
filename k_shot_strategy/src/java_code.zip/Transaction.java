
interface Transaction{
    public int getBeginDay();
    public int getEndDay();
}

